Tuitui.userModel = Backbone.Model.extend({

	initialize: function() {

		console.log("M:user");

	},

	getUser: function() {
		

	}


});
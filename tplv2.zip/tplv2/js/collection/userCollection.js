Tuitui.userList = Backbone.Collection.extend({

	initialize: function() {

		
	},

	model: Tuitui.userModel
});
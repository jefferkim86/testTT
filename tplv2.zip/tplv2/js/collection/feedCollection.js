Tuitui.feedList = Backbone.Collection.extend({

	initialize: function() {

		
	},

	model: Tuitui.feedModel
});